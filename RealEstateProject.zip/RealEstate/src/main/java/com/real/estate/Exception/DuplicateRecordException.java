package com.real.estate.Exception;

public class DuplicateRecordException extends Exception{

	public DuplicateRecordException(String msg) {

		super(msg);
	}
}
