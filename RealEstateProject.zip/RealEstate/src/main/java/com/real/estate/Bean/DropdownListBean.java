package com.real.estate.Bean;

public interface DropdownListBean {

	public String getKey();

	public String getValue();
}
