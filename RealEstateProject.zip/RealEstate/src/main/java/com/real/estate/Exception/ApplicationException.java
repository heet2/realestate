package com.real.estate.Exception;

public class ApplicationException extends Exception{

	public ApplicationException(String msg) {
		super(msg);
	}
}
