package com.real.estate.Ctl;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.real.estate.Bean.BaseBean;
import com.real.estate.Bean.PropertyBean;
import com.real.estate.Bean.UserBean;
import com.real.estate.Model.PropertyModel;
import com.real.estate.Utility.DataUtility;
import com.real.estate.Utility.ServletUtility;

@WebServlet(name = "InquirieCtl", urlPatterns = "/Inquiries")
public class InquirieCtl extends BaseCtl {
	private static final long serialVersionUID = 1L;
	public static final String OP_BOOK= "Book";

	public InquirieCtl() {
		super();
	}

	protected BaseBean populateBean(HttpServletRequest request) {

		PropertyBean bean = new PropertyBean();
		bean.setId(DataUtility.getLong(request.getParameter("id")));
		bean.setPropertytitle(DataUtility.getString(request.getParameter("title")));
		bean.setPropertyowner(DataUtility.getString(request.getParameter("owner")));
		bean.setPropertytype(DataUtility.getString(request.getParameter("type")));
		bean.setSqurerate(DataUtility.getString(request.getParameter("sqrrate")));
		bean.setPrice(DataUtility.getString(request.getParameter("price")));
		bean.setAddresss(DataUtility.getString(request.getParameter("Address")));
		bean.setDescription(DataUtility.getString(request.getParameter("description")));
		bean.setStatus("Booked");
		bean.setHall(DataUtility.getString(request.getParameter("hall")));
		bean.setBalcony(DataUtility.getString(request.getParameter("balcony")));
		bean.setBathroom(DataUtility.getString(request.getParameter("bathroom")));
		bean.setKitchan(DataUtility.getString(request.getParameter("kitchan")));
		bean.setBedroom(DataUtility.getString(request.getParameter("bedroom")));
		bean.setImage(DataUtility.getString(request.getParameter("image")));
		populateDTO(bean, request);
		return bean;

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PropertyModel model = new PropertyModel();
		long id = DataUtility.getLong(request.getParameter("id"));
		if (id > 0) {
			PropertyBean bean = null;
			try {
				bean = model.findByPk(id);
			} catch (Exception e) {
				e.printStackTrace();
			}
			String status =DataUtility.getString(request.getParameter("status"));
			System.out.println("status :" + status);
			bean.setStatus(status);
			ServletUtility.setbean(bean, request);
		}
		ServletUtility.forward(getView(), request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		PropertyModel model = new PropertyModel();
		System.out.println("in do post");
		String op = DataUtility.getString(request.getParameter("operation"));
		long id = DataUtility.getLong(request.getParameter("id"));
		PropertyBean bean = new PropertyBean();
		bean = (PropertyBean) populateBean(request);
		if (OP_BOOK.equalsIgnoreCase(op)) {
			long i = model.ReqUpdate(bean);
			ServletUtility.setSuccessMessage("Property Booked Successfully", request);
			ServletUtility.setbean(bean, request);
		} else {
			try {
				ServletUtility.setErrorMessage("Property Not Booked", request);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		ServletUtility.forward(getView(), request, response);
	}

	@Override
	protected String getView() {
		return REView.Inquiries_VIEW;
	}

}
