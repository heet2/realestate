package com.real.estate.Bean;


public class Demo {

	public static void main(String[] args) {
		StringBuffer sb = new StringBuffer("mukesh ahir");
	    sb.insert(6, "Yadav");
	    System.out.println(sb);
	  }
	
}
