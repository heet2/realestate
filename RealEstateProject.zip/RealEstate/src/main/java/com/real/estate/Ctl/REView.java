package com.real.estate.Ctl;

public interface REView {

	public String APP_CONTEXT = "/RealEstate";
	public String PAGE_FOLDER = "/jsp";

	// Controller------------------------------
	public String WELCOME_CTL = APP_CONTEXT + "/welcome";
	public String LOGIN_CTL = APP_CONTEXT + "/login";
	public String REGISTRATION_CTL = APP_CONTEXT + "/register";
	public String USER_CTL = APP_CONTEXT + "/user";
	public String USER_LIST_CTL = APP_CONTEXT + "/userlist";
	public String PROPERTY_CTL = APP_CONTEXT + "/property";
	public String PROPERTY_LIST_CTL = APP_CONTEXT + "/propertylist";
	public String Inquiries_CTL = APP_CONTEXT + "/Inquiries";
	public String Inquiries_LIST_CTL = APP_CONTEXT + "/Bookinglist";
	public String IMAGE_CTL = APP_CONTEXT + "/image";
	public String ALL_PROPERTY_CTL = APP_CONTEXT + "/allProperty";
	
	// View-------------------------------------
	public String WELCOME_VIEW = PAGE_FOLDER + "/Welcome1.jsp";
	public String REGISTRATION_VIEW = PAGE_FOLDER + "/Registration.jsp";
	public String LOGIN_VIEW = PAGE_FOLDER + "/Login.jsp";
	public String DashBoard = PAGE_FOLDER + "/welcome.jsp";
	public String USER_VIEW = PAGE_FOLDER + "/User.jsp";
	public String USER_LIST_VIEW = PAGE_FOLDER + "/UserList.jsp";
	public String PROPERTY_VIEW = PAGE_FOLDER + "/AddProperty.jsp";
	public String PROPERTY_LIST_VIEW = PAGE_FOLDER + "/PropertyList.jsp";
	public String Inquiries_VIEW = PAGE_FOLDER + "/Inquirie.jsp";
	public String Inquiries_LIST_VIEW = PAGE_FOLDER + "/InquiryList.jsp";
	public String IMAGE_VIEW = PAGE_FOLDER + "/Image.jsp";
	public String ALL_PROPERTY_VIEW = PAGE_FOLDER + "/AllPropertyView.jsp";
}
