package com.real.estate.Ctl;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.real.estate.Bean.PropertyBean;
import com.real.estate.Bean.UserBean;
import com.real.estate.Model.PropertyModel;
import com.real.estate.Utility.DataUtility;
import com.real.estate.Utility.ServletUtility;

/**
 * Servlet implementation class InquiryListCtl
 */
@WebServlet(name = "InquiryListCtl", urlPatterns = "/Bookinglist")
public class InquiryListCtl extends BaseCtl {
	private static final long serialVersionUID = 1L;

	public InquiryListCtl() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PropertyModel model = new PropertyModel();
		PropertyBean bean = null;
		long id = DataUtility.getLong(request.getParameter("id"));

		if (id > 0) {
			model.delete(id);
			ServletUtility.setSuccessMessage("Data Deleted Successfully", request);
		}

		List list = null;
		HttpSession session = request.getSession(false);
		UserBean bean2 = (UserBean) session.getAttribute("user");
		long roleid = bean2.getRoleid();
		if (roleid == 2) {
			try {
				System.out.println("in BuyerRequest method");
				list = model.byerlist(bean2.getId());
			} catch (Exception e) {
			}
		} else {
		try {
			System.out.println("in do get");
			list = model.Request();
		} catch (Exception e) {
			e.printStackTrace();
		}
		}
		if (list == null && list.size() == 0) {
			ServletUtility.setErrorMessage("No record found", request);
		}
		ServletUtility.setList(list, request);
		ServletUtility.forward(getView(), request, response);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	}

	@Override
	protected String getView() {
		return REView.Inquiries_LIST_VIEW;
	}

}
